@echo off
REM ============================================================
REM FIDS — bazni URL aplikacije (dijeljena konfiguracija)
REM
REM Ovaj fajl MORA ostati u ISTOM folderu kao i svi setup-*.bat
REM fajlovi (svaki setup-*.bat ga automatski poziva preko call
REM "%~dp0_base-url.bat" — %~dp0 je folder u kom se on nalazi,
REM pa radi bez obzira gdje folder kopiras).
REM
REM Ako se production URL ikad promijeni (novi domen, drugi
REM Vercel projekat...), izmijeni SAMO liniju ispod — svih 37
REM setup-*.bat fajlova ce automatski pokupiti novu vrijednost,
REM bez potrebe da se svaki fajl pojedinacno edituje.
REM ============================================================
set "BASE_URL=https://fids-tiv.vercel.app"

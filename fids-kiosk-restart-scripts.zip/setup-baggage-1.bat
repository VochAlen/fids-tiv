@echo off
setlocal EnableDelayedExpansion

REM ============================================================
REM FIDS Kiosk — Baggage Claim 1 (PROVJERI RUTU!)
REM Pokreni KAO ADMINISTRATOR (desni klik -> Run as administrator).
REM
REM Radi sve u jednom prolazu:
REM   1. Kreira C:\FIDS\restart-kiosk.bat za OVAJ ekran
REM   2. Kreira Task Scheduler zadatak "FIDS Kiosk Restart" (svako vece
REM      u 03:30) — SAMO ako vec ne postoji na ovom uredjaju
REM   3. Odmah ga jednom pokrene, radi provjere
REM
REM URL za ovaj ekran dolazi iz _base-url.bat (mora biti u istom
REM folderu kao i ovaj fajl) + fiksna putanja ispod.
REM ============================================================

call "%~dp0_base-url.bat"
REM ============================================================
REM PAZNJA: ruta /baggage NIJE pronadjena u trenutnom FIDS
REM projektu (nema app/baggage foldera). Ispod je PLACEHOLDER —
REM izmijeni KIOSK_URL liniju gore rucno kad se potvrdi prava
REM ruta, prije nego pustis ovu skriptu na fizickom uredjaju.
REM ============================================================

set "KIOSK_URL=%BASE_URL%/baggage/1"
set "TASK_NAME=FIDS Kiosk Restart"

REM ── 1. Provjeri administratorska prava ──
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [GRESKA] Ova skripta mora biti pokrenuta KAO ADMINISTRATOR.
  echo Desni klik na fajl -^> "Run as administrator", pa ponovo pokreni.
  pause
  exit /b 1
)

echo ============================================================
echo  Baggage Claim 1 (PROVJERI RUTU!)
echo  URL: %KIOSK_URL%
echo ============================================================
echo.

REM ── 2. Kreiraj C:\FIDS folder ──
if not exist "C:\FIDS" mkdir "C:\FIDS"

REM ── 3. Napisi restart-kiosk.bat za OVAJ ekran ──
(
  echo @echo off
  echo REM ── FIDS kiosk — nocni restart Chrome procesa ──────────────
  echo REM Generisano automatski — Baggage Claim 1 (PROVJERI RUTU!)
  echo.
  echo REM 1. Ugasi SVE Chrome procese ^(force, /T = i child procese^)
  echo taskkill /F /IM chrome.exe /T ^>nul 2^>^&1
  echo timeout /t 3 /nobreak ^>nul
  echo.
  echo REM 2. Nadji instalirani Chrome ^(64-bit ili 32-bit putanja^)
  echo set "CHROME_EXE=C:\Program Files\Google\Chrome\Application\chrome.exe"
  echo if not exist "%%CHROME_EXE%%" set "CHROME_EXE=C:\Program Files ^(x86^)\Google\Chrome\Application\chrome.exe"
  echo.
  echo REM 3. Ponovo upali u kiosk modu, cist ^(bez restore session-a^)
  echo start "" "%%CHROME_EXE%%" --kiosk "%KIOSK_URL%" --noerrdialogs --disable-infobars --disable-session-crashed-bubble --disable-restore-session-state --overscroll-history-navigation=0 --disable-pinch
) > "C:\FIDS\restart-kiosk.bat"

echo [OK] Kreiran C:\FIDS\restart-kiosk.bat
echo.

REM ── 4. Kreiraj Task Scheduler zadatak, SAMO ako vec ne postoji ──
schtasks /query /tn "%TASK_NAME%" >nul 2>&1
if !errorlevel! equ 0 (
  echo [INFO] Zadatak "%TASK_NAME%" vec postoji — preskacem kreiranje.
  echo        ^(restart-kiosk.bat je ipak osvjezen sa trenutnim URL-om^)
) else (
  schtasks /create /tn "%TASK_NAME%" /tr "C:\FIDS\restart-kiosk.bat" /sc daily /st 03:30 /ru SYSTEM /rl HIGHEST /f
  if !errorlevel! equ 0 (
    echo [OK] Zadatak "%TASK_NAME%" kreiran — pokrece se svako vece u 03:30.
  ) else (
    echo [GRESKA] Kreiranje Task Scheduler zadatka nije uspjelo.
    pause
    exit /b 1
  )
)

echo.
echo ── Pokrecem zadatak sada, radi provjere ──
echo Chrome ce se za par sekundi ugasiti i ponovo upaliti na: %KIOSK_URL%
schtasks /run /tn "%TASK_NAME%"

echo.
echo Gotovo. Provjeri da li se Chrome ponovo otvorio ispravno.
pause
